
import UserBookNewRequest from "User/UserBookNew/UserBookNewRequest";
import UserInProgressRequest from "User/UserInProgress/UserInProgressRequest";
import UserCompletedRequest from "User/UserCompleted/UserCompletedRequest";
import UserQuotes from "User/UserQuotes/UserQuotes";
import UserMessages from "User/UserMessages/UserMessages";
import UserInvoices from "User/UserInvoices/UserInvoices";
import UserProfile from "User/UserProfile/UserProfile";
import UserHelpSupport from "User/UserHelpSupport/UserHelpSupport";
import UserDashboard from "User/UserDashboard/UserDashboard";
// import UserShipmentForm from "User/UserShipmentRequest/UserShipmentForm";
// import UserLogOut from "User/UserLogout/UserLogout";
// import NewBookingForm from "User/UserShipmentRequest/NewBookingForm";
// import ShipmentDetailsShipment from "User/UserShipmentRequest/ShipmentDetails";
import ShipmentDetailsShipment from "User/UserShipmentRequest/ShipmentDetails";
import ShipmentDetailsCustom from "User/UserCustomRequest/ShipmentDetailsCustom";

var userRoutes = [
  {
    path: "/home",
    name: "Home (Dashboard)",
    icon: "fas fa-tachometer-alt text-primary mr-3", // Dashboard icon
    component: <UserDashboard />,
    layout: "/admin",
  },
  {
    path: "/bookNew",
    name: "Book New",
    icon: "fas fa-inbox text-primary mr-3", // Book icon
    component: <UserBookNewRequest />,
    layout: "/admin",
  },
  {
    path: "/progress",
    name: "In Progress",
    icon: "fas fa-spinner text-primary mr-3", // Spinner icon for in-progress
    component: <UserInProgressRequest />,
    layout: "/admin",
  },
  {
    path: "/completed",
    name: "Completed",
    icon: "fas fa-check-circle text-primary mr-3", // Check-circle icon for completed
    component: <UserCompletedRequest />,
    layout: "/admin",
  },
  {
    path: "/quotes",
    name: "Quotes (From Admin)",
    icon: "fas fa-file-invoice text-primary mr-3", // Invoice icon for quotes
    component: <UserQuotes />,
    layout: "/admin",
  },
  {
    path: "/messages",
    name: "Messages",
    icon: "fas fa-comments text-primary mr-3", // Comments icon for messages
    component: <UserMessages />,
    layout: "/admin",
  },
  {
    path: "/invoices",
    name: "Invoices",
    icon: "fas fa-file-invoice-dollar text-primary mr-3", // File invoice icon for invoices
    component: <UserInvoices />,
    layout: "/admin",
  },
  {
    path: "/profile",
    name: "Profile",
    icon: "fas fa-user-circle text-primary mr-3", // User circle icon for profile
    component: <UserProfile />,
    layout: "/admin",
  },
  {
    path: "/help&support",
    name: "Help & Support",
    icon: "fas fa-question-circle text-primary mr-3", // Question-circle icon for help and support
    component: <UserHelpSupport />,
    layout: "/admin",
  },
  {
    path: "/shippingform",
    name: "Shipping Form",
    icon: "fas fa-question-circle text-primary mr-3", // Question-circle icon for help and support
    component: <ShipmentDetailsShipment />,
    layout: "/admin",
  },
  {
    path: "/customform",
    name: "Custom Form",
    icon: "fas fa-question-circle text-primary mr-3", // Question-circle icon for help and support
    component: <ShipmentDetailsCustom />,
    layout: "/admin",
  },
  {
    path: "/logout",
    name: "Logout",
    icon: "fas fa-sign-out-alt text-primary mr-3", // Sign-out-alt icon for logout
    component: <UserHelpSupport />,
    layout: "/user",
  },
];

export default userRoutes;

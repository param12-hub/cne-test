import React from "react";
import { useLocation, Route, Routes, Navigate } from "react-router-dom";
// reactstrap components
import { Container } from "reactstrap";
// core components
import UserNavbar from "components/Navbars/AdminNavbar";  // Use the user-specific Navbar
import UserFooter from "components/Footers/AdminFooter";  // Use the user-specific Footer
import Sidebar from "components/Sidebar/Sidebar.js";  // If users need a sidebar too

import userRoutes from "../userRoute.js";  // User-specific routes

const User = (props) => {
  const mainContent = React.useRef(null);
  const location = useLocation();

  React.useEffect(() => {
    document.documentElement.scrollTop = 0;
    document.scrollingElement.scrollTop = 0;
    mainContent.current.scrollTop = 0;
  }, [location]);

  const getRoutes = (userRoutes) => {
    return userRoutes.map((prop, key) => {
      if (prop.layout === "/user") {
        return (
          <Route path={prop.path} element={prop.component} key={key} exact />
        );
      } else {
        return null;
      }
    });
  };

  const getBrandText = (path) => {
    for (let i = 0; i < userRoutes.length; i++) {
      if (
        props?.location?.pathname.indexOf(userRoutes[i].layout + userRoutes[i].path) !==
        -1
      ) {
        return userRoutes[i].name;
      }
    }
    return "User Dashboard";
  };

  return (
    <>
      <Sidebar
        {...props}
        routes={userRoutes}
        logo={{
          innerLink: "/user/index",  // Adjust the user logo link
          imgSrc: require("../assets/img/brand/argon-react.png"),
          imgAlt: "User Logo",
        }}
      />
      <div className="main-content" ref={mainContent}>
        <UserNavbar
          {...props}
          brandText={getBrandText(props?.location?.pathname)}
        />
        <Routes>
          {getRoutes(userRoutes)}
          <Route path="*" element={<Navigate to="/user/index" replace />} />
        </Routes>
        <Container fluid>
          <UserFooter />
        </Container>
      </div>
    </>
  );
};

export default User;

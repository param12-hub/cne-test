import React, { useState } from 'react';
import './UserMessages.css';

const UserMessages = () => {
    const [conversations, setConversations] = useState([
        { id: 'REQ001', messages: ['Hello, I have a question regarding my request.'] },
        { id: 'REQ002', messages: ['Can you provide an update on my order?'] },
        { id: 'REQ003', messages: ['Please share the invoice for this request.'] },
    ]);

    const [newMessage, setNewMessage] = useState('');
    const [selectedConversation, setSelectedConversation] = useState(null);
    const [file, setFile] = useState(null);

    const handleMessageChange = (e) => {
        setNewMessage(e.target.value);
    };

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const sendMessage = () => {
        if (newMessage || file) {
            const updatedConversations = conversations.map((conversation) => {
                if (conversation.id === selectedConversation) {
                    return {
                        ...conversation,
                        messages: [...conversation.messages, newMessage],
                    };
                }
                return conversation;
            });
            setConversations(updatedConversations);
            setNewMessage('');
            setFile(null);
            alert('Message sent successfully.');
        } else {
            alert('Please enter a message or upload a file.');
        }
    };

    return (
        <div className="user-messages-container">
            <h2>Messages</h2>

            {/* Inbox View */}
            <div className="inbox-view">
                <h3>Inbox</h3>
                <ul>
                    {conversations.map((conversation) => (
                        <li
                            key={conversation.id}
                            onClick={() => setSelectedConversation(conversation.id)}
                            className={selectedConversation === conversation.id ? 'selected' : ''}
                        >
                            Request ID: {conversation.id}
                        </li>
                    ))}
                </ul>
            </div>

            {/* Message Window */}
            {selectedConversation && (
                <div className="message-window">
                    <h3>Conversation with Request ID: {selectedConversation}</h3>

                    <div className="message-history">
                        {conversations
                            .find((conversation) => conversation.id === selectedConversation)
                            .messages.map((msg, index) => (
                                <div key={index} className="message">
                                    <p>{msg}</p>
                                </div>
                            ))}
                    </div>

                    <div className="new-message">
                        <textarea
                            value={newMessage}
                            onChange={handleMessageChange}
                            placeholder="Write your message..."
                        ></textarea>
                        <div className="file-upload">
                            <label htmlFor="fileUpload">Attach File:</label>
                            <input
                                type="file"
                                id="fileUpload"
                                onChange={handleFileChange}
                            />
                        </div>
                        <button onClick={sendMessage}>Send Message</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default UserMessages;

import React, { useState } from 'react';
import './UserProfile.css';

const UserProfile = () => {
    const [userProfile, setUserProfile] = useState({
        name: 'John Doe',
        email: 'johndoe@example.com',
        contact: '+1234567890',
        password: '',
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setUserProfile({ ...userProfile, [name]: value });
    };

    const handleProfileUpdate = () => {
        alert('Profile updated successfully!');
    };

    const handlePasswordChange = () => {
        if (userProfile.password) {
            alert('Password changed successfully!');
        } else {
            alert('Please enter a new password.');
        }
    };

    return (
        <div className="user-profile-container">
            <h2>User Profile</h2>

            {/* Edit Profile Section */}
            <div className="edit-profile">
                <h3>Edit Profile</h3>
                <div className="form-group">
                    <label htmlFor="name">Name:</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={userProfile.name}
                        onChange={handleInputChange}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="email">Email:</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={userProfile.email}
                        onChange={handleInputChange}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="contact">Contact Information:</label>
                    <input
                        type="text"
                        id="contact"
                        name="contact"
                        value={userProfile.contact}
                        onChange={handleInputChange}
                    />
                </div>
                <button onClick={handleProfileUpdate}>Update Profile</button>
            </div>

            {/* Change Password Section */}
            <div className="change-password">
                <h3>Change Password</h3>
                <div className="form-group">
                    <label htmlFor="password">New Password:</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={userProfile.password}
                        onChange={handleInputChange}
                    />
                </div>
                <button onClick={handlePasswordChange}>Change Password</button>
            </div>
        </div>
    );
};

export default UserProfile;

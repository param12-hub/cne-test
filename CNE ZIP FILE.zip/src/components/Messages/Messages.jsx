import React, { useState } from 'react';
import './Messages.css';

const Messages = () => {
    const [tab, setTab] = useState('inbox');
    const [selectedRequest, setSelectedRequest] = useState('');
    const [message, setMessage] = useState('');
    const [file, setFile] = useState(null);

    // Mock data
    const conversations = [
        {
            requestId: 'REQ001',
            messages: [
                { text: 'Hello, please update the status.', fromUser: true, unread: true },
                { text: 'Sure, we will update it shortly.', fromUser: false, unread: false },
            ],
        },
        {
            requestId: 'REQ002',
            messages: [
                { text: 'Can I get an estimated delivery time?', fromUser: true, unread: false },
            ],
        },
    ];

    const handleTabChange = (newTab) => {
        setTab(newTab);
    };

    const handleSendMessage = () => {
        if (!selectedRequest || !message) {
            alert('Please select a request and enter a message.');
            return;
        }

        alert(`Message sent for ${selectedRequest}: ${message}`);
        setMessage('');
        setFile(null);
    };

    const renderInbox = () => {
        return (
            <div className="inbox-container">
                {conversations.map((conv) => (
                    <div key={conv.requestId} className="conversation">
                        <div className="conversation-header">
                            <strong>Request ID: {conv.requestId}</strong>
                            {conv.messages.some((msg) => msg.unread) && <span className="unread">Unread</span>}
                        </div>
                        <div className="conversation-body">
                            {conv.messages.map((msg, index) => (
                                <div
                                    key={index}
                                    className={msg.fromUser ? 'message user' : 'message admin'}
                                >
                                    {msg.text}
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        );
    };

    const renderCompose = () => {
        return (
            <div className="compose-container">
                <div className="form-group">
                    <label htmlFor="requestId">Select Request ID</label>
                    <select
                        id="requestId"
                        value={selectedRequest}
                        onChange={(e) => setSelectedRequest(e.target.value)}
                    >
                        <option value="">-- Select Request --</option>
                        {conversations.map((conv) => (
                            <option key={conv.requestId} value={conv.requestId}>
                                {conv.requestId}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="message">Message</label>
                    <textarea
                        id="message"
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Enter your message here"
                    ></textarea>
                </div>

                <div className="form-group">
                    <label htmlFor="file">Attach File</label>
                    <input
                        type="file"
                        id="file"
                        onChange={(e) => setFile(e.target.files[0])}
                    />
                </div>

                <button onClick={handleSendMessage}>Send Message</button>
            </div>
        );
    };

    return (
        <div className="messages-container">
            <div className="tab-menu">
                <button className={tab === 'inbox' ? 'active' : ''} onClick={() => handleTabChange('inbox')}>
                    Inbox
                </button>
                <button className={tab === 'compose' ? 'active' : ''} onClick={() => handleTabChange('compose')}>
                    Compose Message
                </button>
            </div>

            <div className="tab-content">
                {tab === 'inbox' ? renderInbox() : renderCompose()}
            </div>
        </div>
    );
};

export default Messages;

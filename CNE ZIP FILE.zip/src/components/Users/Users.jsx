import React, { useState } from 'react';
import './Users.css';

const Users = () => {
    const [users, setUsers] = useState([
        { userName: 'John Doe', email: 'john.doe@example.com', status: 'Active' },
        { userName: 'Jane Smith', email: 'jane.smith@example.com', status: 'Inactive' },
    ]);

    const toggleAccountStatus = (email) => {
        setUsers((prevUsers) =>
            prevUsers.map((user) =>
                user.email === email
                    ? { ...user, status: user.status === 'Active' ? 'Inactive' : 'Active' }
                    : user
            )
        );
    };

    const viewUserRequests = (userName) => {
        alert(`Viewing requests for: ${userName}`);
    };

    return (
        <div className="users-container">
            <h2>Users</h2>

            <div className="list-view">
                <table className="users-table">
                    <thead>
                        <tr>
                            <th>User Name</th>
                            <th>Email</th>
                            <th>Account Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map((user) => (
                            <tr key={user.email}>
                                <td>{user.userName}</td>
                                <td>{user.email}</td>
                                <td>{user.status}</td>
                                <td>
                                    <button style={{ marginRight: '10px' }} onClick={() => viewUserRequests(user.userName)}>
                                        View User Requests
                                    </button>
                                    <button onClick={() => toggleAccountStatus(user.email)}>
                                        {user.status === 'Active' ? 'Deactivate' : 'Activate'} Account
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Users;
